# bromo-lib
This is the Bromo library repository for python. It is intended to make interaction with the browser easier and more fluid using selenium loading strategies.



# Use:
As the library is not officially released, one way to use it is to download it and leave it on the same page as the code.

From bromo import Bromo
From Selenium Import Webdriver

driver = Webdriver.Chrome()

br = Bromo(driver)

example:

br.click(xpath)



# Contact:
email: leonardo_leal15@outlook.com
