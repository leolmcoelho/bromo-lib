# bromo-lib
This is the Bromo library repository for python. It is intended to make interaction with the browser easier and more fluid using selenium loading strategies.



# Use:
For your use, run the command on the terminal 

~~~
pip install Bromo==0.1 

OR 

pip3 install Bromo==0.1
~~~

~~~python
From bromo import Bromo
From Selenium Import Webdriver

driver = Webdriver.Chrome()

br = Bromo(driver)

example:

br.click(xpath)
~~~


# Contact:
email: leonardo_leal15@outlook.com
