# bromo-lib
This is the Bromo library repository for python. It is intended to make interaction with the browser easier and more fluid using selenium loading strategies.



# Use:
For your use, run the command on the terminal 

~~~
pip install Bromo

OR 

pip3 install Bromo
~~~

~~~python

From bromo.Bromo import Bromo
From Selenium Import Webdriver

driver = Webdriver.Chrome()

br = Bromo(driver)

example:

br.click(xpath)
~~~


# Contact:
email: leonardo_leal15@outlook.com
